
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var connectionSchema = new Schema({
    connectionID : {type : String},
    connectionName : {type : String}, 
    connectionTopic :{type : String},
    connectionDetails : {type : String},
    date : {type : String},
    time: {type : String},
    location: {type : String},
    hostedBy : {type : String},
    image: {type : String},
    going_yes : {type : String},
    going_no : {type : String},
    going_maybe : {type : String},
    userID : {type : Number}
},{collection : 'connections'});

var Connections = mongoose.model('connections',connectionSchema);
module.exports = Connections;
