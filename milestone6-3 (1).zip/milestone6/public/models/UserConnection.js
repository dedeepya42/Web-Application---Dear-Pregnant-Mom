
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userConnectionSchema = new Schema({
    conID : {type : String, required : true},
    conName : {type : String},
    conTopic : {type : String},
    rsvp : {type :String},
    userID : {type : Number},
    hostedBy : {type : String}
},{collection : 'userConnections'});

var UserConnections = mongoose.model('userConnections',userConnectionSchema);
module.exports = UserConnections;
