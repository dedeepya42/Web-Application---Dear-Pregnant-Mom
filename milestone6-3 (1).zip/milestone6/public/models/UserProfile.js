var UserConnection = require('./UserConnection');
var ConnectionDB = require('../utility/connectionDB');
var UserDB = require('../utility/UserDB');
var UserConnectionDB = require('../utility/UserConnectionDB');

// creating data objects for user profile
function UserProfile(userID , userConnections){
    this.userID = userID;
    this.userConnections = userConnections;
}

// function to add a Connection
var addConnection = async function(conID,connections,rsvp,userID,host){
      console.log("Adding connection to the User Profile");
      var connection = await UserConnectionDB.addRSVP(conID,rsvp,userID,host);
      return connection;
}

//function to remove a connection
var removeConnection =  async function(conID, connections,userID){
    console.log("Removing the connection from the User profile");
    connections = await UserConnectionDB.removeConnection(conID,userID);
    return connections;
}

//function to update a connection
var updateConnection = async function(conID, connections , rsvp,userID){
    console.log("Updating connection from User Profile");
    connections = await UserConnectionDB.updateRSVP(conID, userID , rsvp);
     return connections;
   };

//method for empty profile
var emptyProfile = function(){
  delete UserConnectionDB.getUserProfile(1);
}

module.exports = UserProfile;
module.exports.addConnection = addConnection;
module.exports.removeConnection = removeConnection;
module.exports.updateConnection = updateConnection;
module.exports.emptyProfile = emptyProfile;
