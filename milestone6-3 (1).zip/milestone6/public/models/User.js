var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
    userID : {type : Number, required : true},
    firstName : {type : String, required : true},
    lastName : {type : String},
    email : {type : String, required : true},
    address: {type : String},
    city: {type : String},
    state: {type : String},
    zipcode : {type : Number},
    country: {type : String},
    password : {type : String},
},{collection : 'users'});

var Users = mongoose.model('users',userSchema);
module.exports = Users;
