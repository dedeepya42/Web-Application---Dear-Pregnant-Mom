var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({extended : false});
var conUtil = require('../utility/connectionDB');
var userUtil = require('../utility/UserDB');
var UserProfile = require('../models/UserProfile');
var User = require('../models/User');
var session = require('express-session');
var UserConnectionDB = require('../utility/UserConnectionDB');
const { check, validationResult } = require('express-validator')
var bcrypt = require('bcryptjs');

router.use(session({secret: 'user secret',resave: true, saveUninitialized: true}));


/*-----------route for '/'------------*/
router.get('/' , function(req,res){
    if(req.session.theUser){
    res.render('index',{firstName : req.session.theUser[0].firstName});
    }
    else{
        res.render('index',{firstName: ''});
    }
 });

/*-------Route for My Connections page------------*/
 router.get('/myConnections', async function(req,res){
     if(req.session.theUser){
        var userID = req.session.theUser[0].userID;
        var userProfile = await UserConnectionDB.getUserProfile(userID);
        req.session.viewList = userProfile;
        console.log("User logged in and is in session");
        console.log("Welcome " +req.session.theUser[0].firstName);
        var data = {
            userProfile : userProfile, 
            firstName : req.session.theUser[0].firstName 
        }
        res.render('myConnections' ,{view: data,firstName : req.session.theUser[0].firstName})
        }
    else{
        res.render('loginRequired',{view:data, firstName : ''});
    }
});

/*---Adds a connection to the user profile if the connection id does not already exist in the user profile---*/
/*---Updates the connection , if the connection id is already present in the user profile---*/

router.post('/save', urlencodedParser, async function(req,res){
        if(req.session.theUser == null || req.session.theUser == undefined)
        {
        res.render('loginRequired',{firstName : ''});
        }
    else{
        var connections = await req.session.viewList;
        var conID = req.body.viewConnection;
        var flag = 0;
    for(var i=0; i<connections.length; i++)
        {
        if(conID == connections[i].conID){
            flag = 1;
        }
    }
    if(flag == 1){
        /*---- Updating the connection from the user profile----*/
            console.log("Updating the connection as the connection id is same");
            var conID = req.body.viewConnection;
            var new_rsvp = req.body.action;
            var userID = req.session.theUser[0].userID;
            var connections = await UserProfile.updateConnection(conID,req.session.viewList,new_rsvp,userID);
            console.log("User profile after updating the rsvp is as follows : ");
            console.log(connections);
            req.session.viewList = connections;
            var data ={
                userProfile : connections
        }
            res.render('myConnections',{view: data, firstName : req.session.theUser[0].firstName})
        }
/*----------Adding a connection to the user profile---------*/
    else{
        console.log("Adding the connection as the connection id is different");
        var action = req.body.action;
        var conID = req.body.viewConnection;
        var userID = req.session.theUser[0].userID;
        var host = req.body.host;
        var connections = await UserProfile.addConnection(conID,req.session.viewlist,action,userID,host);
        req.session.viewList = connections;
        console.log("User profile after adding a connection is as follows : ");
        console.log(connections);
        var data ={
            userProfile : connections
        }
        res.render('myConnections' , {view : data, firstName : req.session.theUser[0].firstName});   
    }
}
});

/**----------------Deletes a connection------------------**/

router.post('/delete', urlencodedParser, async function(req,res){
    if(req.session.theUser){
        var userID = req.session.theUser[0].userID;
        var userProfile = await UserConnectionDB.getUserProfile(userID);
        var firstName = req.session.theUser[0].firstName;
        var host = req.body.host;
    if(firstName === host){
        /*----Delete the connection from database---*/
        console.log("Delete the connection from the database");
        var conID = req.body.viewConnection;
        var connections = await UserConnectionDB.removeConFromDB(conID,req.session.viewList,userID,host);
        console.log("After deleting the connection from database");
        console.log(connections);
        /*-----Delete the connection from user profile-----*/
        var conID = req.body.viewConnection;
        var connections = await UserProfile.removeConnection(conID,req.session.viewList,userID);
        console.log("Deleting the connection selected ");
        console.log("User profile after the selected connection is deleted is as follows : ")
        console.log(connections);
        req.session.viewList = connections;
         var data = {
            userProfile : connections
        }
    res.render('myConnections' , {view : data, firstName : req.session.theUser[0].firstName});
    }
    else{
        var conID = req.body.viewConnection;
        var userID = req.session.theUser[0].userID;
        var connections = await UserProfile.removeConnection(conID,req.session.viewList,userID);
        console.log("Deleting the connection selected ");
        console.log("User profile after the selected connection is deleted is as follows : ")
        console.log(connections);
        req.session.viewList = connections;
        var data = {
            userProfile : connections
        }
        res.render('myConnections' , {view : data, firstName : req.session.theUser[0].firstName});
}
    }
else if(req.session.theUser == null || req.session.theUser == undefined){
    res.render('loginRequired',{firstName : ''});
}
});

/*----------------- Adds a new connection to the database -------------------*/
router.post('/newConnection',urlencodedParser, [
    check('connectionName').matches(/[a-zA-Z\s]$/).
    withMessage("connection name should have only alphabetic chars with spaces allowed.No special characters are allowed").
    not().isEmpty().withMessage("connection name field should not be empty"),

    check('connectionDetails').matches(/[a-zA-Z0-9\s]$/).
    withMessage("connection details should have only alphabetic chars and numbers with spaces allowed. No special characters are allowed").
    not().isEmpty().withMessage('connection details field should not be empty'),

    check('location').matches(/[a-zA-Z0-9]$/).
    withMessage("location should have only alphabetic chars/numbers with spaces allowed.No special characters are allowed").
    not().isEmpty().withMessage("location field should not be empty"),

    check('date').not().isEmpty().withMessage("date field should not be empty").isAfter().
    withMessage("Date should be after today"),

    check('time').not().isEmpty().withMessage("time field should not be empty")
],async function(req,res){
    const errors = validationResult(req);
if(!errors.isEmpty()){
  return res.status(422).json({errors: errors.array() });
}
    if(req.session.theUser){
    var connections = await conUtil.getConnections();
    let ids = [];
    for(let i=0;i<connections.length;i++){
        ids.push(connections[i].connectionID);
     }
    var lastID = Math.max(...ids);
    conID = (lastID + 1);
    var name = req.body.connectionName;
    var topic = req.body.connectionTopic;
    var details = req.body.connectionDetails;
    var location = req.body.location;
    var host = req.session.theUser[0].firstName;
    var date = req.body.date;
    var time = req.body.time;
    var userID = await req.session.theUser[0].userID;
    var newConnection = UserConnectionDB.addConnection(conID,name,topic,details,location,host,date,time,userID); 
    res.redirect('connections');
    }
else{
    res.render('loginRequired',{firstName:''});
}
});

/*--------- Route for Login -------------------*/
router.post('/login',urlencodedParser,[
    check('username').isEmail().not().isEmpty().
    withMessage("username should not be empty.it should be a valid email address"),

    check('password').isLength({ min: 5 }).
    withMessage('password must be atleast 5 chars long').
    not().isEmpty().withMessage("Password field should not be empty")

], async function(req,res,next){
const errors = validationResult(req);
if(!errors.isEmpty()){
  return res.status(422).json({errors: errors.array() });
}
else{
    var email_entered = req.body.username;
    var password_entered = req.body.password;
    var user = await userUtil.getUserByUsername(email_entered);
    if(user.length == 0){
        console.log("user does not exist in the DB")
        res.render('noUser',{firstName:''});
    }
    else if(user.length!=0){
         req.session.theUser = user;
         bcrypt.compare(req.body.password,user[0].password,function(err,result){
             if(result == true){
                 res.redirect('myConnections')
             }
            else{
                res.render('error',{firstName:''})
            }
          });
    }
}
});

/*--------pre-populate the data in the update connection form ---------*/
router.post('/update', urlencodedParser, async function(req,res){
    if(req.session.theUser){
    var userID = req.session.theUser[0].userID;
    var userProfile = await UserConnectionDB.getUserProfile(userID);
    var firstName = req.session.theUser[0].firstName;
    var host = req.body.host;
    var connectionID = req.body.viewConnection;
    var categories = await conUtil.getCategory();
   if(firstName === host){
        var Details = await conUtil.getConnection(connectionID);
        var data={
         connectionID : Details.connectionID,
         connectionTopic : Details.connectionTopic,
         connectionName :  Details.connectionName,
         connectionDetails : Details.connectionDetails,
         host : Details.hostedBy,
         date : Details.date,
         time : Details.time,
         location : Details.location}
         res.render('updateConnection',{view:data,categories:categories,firstName : req.session.theUser[0].firstName});
        
        }
         else{
        var cid = await conUtil.getConnection(connectionID);
        var data = {
            connection: cid,
        }
        res.render('connection',{view:data,firstName : req.session.theUser[0].firstName});
    }
}
});

/*-------hosted user updates the connection--------*/
router.post('/updateConnection',urlencodedParser, [
    check('connectionName').matches(/[a-zA-Z\s]$/).
    withMessage("connection name should have only alphabetic chars with spaces allowed.No special characters are allowed").
    not().isEmpty().withMessage("connection name field should not be empty"),

    check('connectionDetails').matches(/[a-zA-Z0-9.\s]$/).
    withMessage("connection details should have only alphabetic chars and numbers with spaces allowed.No special characters are allowed").
    not().isEmpty().withMessage('connection details field should not be empty'),

    check('location').matches(/[a-zA-Z0-9]$/).
    withMessage("location should have only alphabetic chars/numbers with spaces allowed.No special characters are allowed.").
    not().isEmpty().withMessage("location field should not be empty"),
    
    check('date').not().isEmpty().withMessage("date field should not be empty").
    isAfter().withMessage("Entered date should be after today"),

    check('time').not().isEmpty().withMessage("time field should not be empty")],
    async function(req,res){
    const errors = validationResult(req);
        if(!errors.isEmpty()){
            return res.status(422).json({errors: errors.array() });
          }
    var conID =  req.body.viewConnection;
    var cTopic = await req.body.connectionTopic;
    var cName = await req.body.connectionName;
    var cDetails = await req.body.connectionDetails;
    var date = await req.body.date;
    var location = await req.body.location;
    var time = await req.body.time; 
    var host = req.body.host;
    UserConnectionDB.updateConnection(conID,cTopic,cName,cDetails,date,location,time,host);
    res.redirect('connections');
});

/*-----------Sign up with validation and hashing password----------------------*/
router.post('/signup',urlencodedParser,[
    check('firstName').matches(/[a-zA-Z\s]$/).
    withMessage("first name should have only alphabetic chars with spaces allowed.No special characters are allowed.").
    not().isEmpty().withMessage("first name field should not be empty").
    isLength({min : 4}).withMessage("The length of first name should be of minimum 4 chars"),

    check('lastName').matches(/[a-zA-Z\s]$/).
    withMessage("last name should have only alphabetic chars with spaces allowed").
    not().isEmpty().withMessage("last name field should not be empty"),

    check('email').isEmail().withMessage("Email field should have a valid email id").
    not().isEmpty().withMessage("Email field should not be empty"),

    check('address').matches(/[a-zA-Z0-9]$/).
    withMessage("address field should have only alphabetic chars/numbers with spaces allowed.No special characters are allowed").
    not().isEmpty().withMessage('address field should not be empty'),

    check('city').matches(/[a-zA-Z\s]$/).
    withMessage("city field should have only alphabetic chars with spaces allowed.No special characters are allowed").
    not().isEmpty().withMessage("city field should not be empty"),

    check('state').matches(/[a-zA-Z\s]$/).
    withMessage("state field should have only alphabetic chars with spaces allowed.No special characters are allowed").
    not().isEmpty().withMessage("state field should not be empty"),

    check('zipcode').isNumeric().
    withMessage("Only numbers are allowed in the zipcode field").
    not().isEmpty().withMessage("zipcode field should not be empty"),

    check('password').not().isEmpty().
    withMessage("password field should not be empty").
    isLength({ min: 5 }).withMessage("password should have minimum 5 chars")]
,async function(req,res){
    const errors = validationResult(req);
if(!errors.isEmpty()){
  return res.status(422).json({errors: errors.array() });
}
    let user = await User.findOne({ email: req.body.email });
    if (user) {
        res.render('Email',{firstName:''});
    } else {
        var users = await userUtil.getUsers();
        let user_ids = [];
        for(let i=0;i<users.length;i++){
        user_ids.push(users[i].userID);
     }
    var lastID = Math.max(...user_ids);
    var userID = (lastID + 1);
        const salt = await bcrypt.genSalt();
        const hashedPassword = await bcrypt.hash(req.body.password,salt);
        user = new User({
            userID : userID,
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            address : req.body.address,
            city : req.body.city,
            state : req.body.state,
            zipcode : req.body.zipcode,
            password: hashedPassword
        });
        await user.save();
        res.redirect('login');
    }
});

/*-----------session is destroyed on logout--------*/

router.get('/logout', function(req,res){
    req.session.destroy(function(err){
      res.render('index', {firstName : ''});
   });
});

module.exports = router;
