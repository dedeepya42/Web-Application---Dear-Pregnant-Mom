var express = require('express');
var router = express.Router();
var utility = require('../utility/connectionDB');
var session = require('express-session');
var users = require('../utility/UserDB');
var UserConnectionDB = require('../utility/UserConnectionDB');

router.use(session({secret: 'user secret',resave: true, saveUninitialized: true}));

router.get('/' , function(req,res){
    if(req.session.theUser){
    res.render('index',{firstName : req.session.theUser[0].firstName});
    }
    else{
        res.render('index',{firstName: ''});
    }
 });

/** get the connection page with connection id */
router.get('/connections/connectionid=:connectionID',async function(req, res){
     if(req.session.theUser){
     var conID = await req.params.connectionID;
     var connections = await utility.getConnections();
     var cid = await utility.getConnection(conID);
     var cat = await utility.getCategory();
     if(cid == undefined || cid == null)
    {
        console.log("connection id is undefined")
        var data = {connections: connections, category: cat };
        res.render('connections',{view:data, firstName : req.session.theUser[0].firstName});
    }
    else{
        var data ={ connection: cid };
        res.render('connection',{view:data , firstName : req.session.theUser[0].firstName});
    }
}
else{
        var conID = await req.params.connectionID;
        var connections = await utility.getConnections();
        var cid = await utility.getConnection(conID);
        var cat = await utility.getCategory();
        if(cid == undefined || cid == null)
        {
            var data = {connections: connections, category: cat };
            res.render('connections',{view:data,firstName : ''});
        }
        else{
        //console.log("welcome to the connection entered")
            var data ={ connection: cid };
            res.render('connection',{view:data , firstName : ''});
        }

    }
    });

    /** ---Connections Page ---- */
    router.get('/connections',async function(req,res){
        if(req.session.theUser){
        var connections = await utility.getConnections();
        //var cat = ["Health, Nutrition and Fitness", "Fun and Stress bursters"];
        var cat = await utility.getCategory();
        var data={ connections: connections, category : cat };
        res.render('connections',{view:data, firstName : req.session.theUser[0].firstName});
        }
        else{
            var connections = await utility.getConnections();
        var cat = await utility.getCategory();
        var data={ connections: connections, category : cat };
        res.render('connections',{view:data, firstName : ''});
        }
    });


 /** -----Contact Us page------ */
    router.get('/contact',function(req,res){
        if(req.session.theUser){
            res.render('contact',{firstName : req.session.theUser[0].firstName});
            }
            else{
                res.render('contact',{firstName: ''});
            }
    });

/** -----About Us page----- */
    router.get('/about',function(req,res){
        if(req.session.theUser){
            res.render('about',{firstName : req.session.theUser[0].firstName});
            }
            else{
                res.render('about',{firstName: ''});
            }
    });

/** ------saved Connections page------ */

router.get('/myConnections',function(req,res){
    console.log("Entered the my connections");
    if(req.session.theUser){
        res.render('myConnections',{firstName : req.session.theUser[0].firstName});
        }
        else{
            res.render('myConnections',{firstName: ''});
        }
});

/***----- Start a new connection page------ */
router.get('/newConnection',async function(req,res){
    var connections = await utility.getConnections();
    const categories = await utility.getCategory();
    if(req.session.theUser){
        res.render('newConnection',{firstName : req.session.theUser[0].firstName, categories: categories});
        }
        else{
            res.render('newConnection',{firstName: '' , categories : categories});
        }
});

/***----- index page------ */
router.get('/index',function(req,res){
    if(req.session.theUser){
        res.render('index',{firstName : req.session.theUser[0].firstName});
        }
        else{
            res.render('index',{firstName: ''});
        }
});

/*----Login page----------*/
router.get('/login',function(req,res){
    if(req.session.theUser){
        res.render('login',{firstName : req.session.theUser[0].firstName});
        }
        else{
            res.render('login',{firstName: ''});
        }
});

/*----Login page----------*/
router.get('/signup',function(req,res){
    if(req.session.theUser){
        res.render('signup',{firstName : req.session.theUser[0].firstName});
        }
        else{
            res.render('signup',{firstName: ''});
        }
});

/***---Go to Any other - 404 displayed ----*/
router.get('/*',function(req,res){
    if(req.session.theUser){
        res.render('404',{firstName : req.session.theUser[0].firstName});
        }
        else{
            res.render('404',{firstName: ''});
        }
});


module.exports = router;
