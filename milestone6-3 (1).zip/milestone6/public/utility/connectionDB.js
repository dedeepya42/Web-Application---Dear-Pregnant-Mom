var Connection = require('../models/connection');

 //This function retrieves all the connections from the DB
 var getConnections = async function(){
  return new Promise( function(resolve, reject){
       Connection.find().then(function(connections){
          resolve(connections);
      }).catch(function(err){
          console.log(err);
          return reject(err);
      });

  });   
}

//This function retrieves the particular connection with matching connection id from the DB
var getConnection = async function(conID){
  return new Promise(function(resolve, reject){
      Connection.findOne({connectionID:conID}).then(function(connection){
          resolve(connection);
      }).catch(function(err){
          console.log(err);
          return reject(err);
      });
  });  
}

//This function retrieves categories from the list of connections.
var getCategory = async function(){
var categories = [];
var connections = await getConnections();
connections.forEach(function (connection) {
  if(!categories.includes(connection.connectionTopic)){
      categories.push(connection.connectionTopic);
  }
});
return categories;
}

module.exports.getConnections = getConnections;
module.exports.getConnection = getConnection;
module.exports.getCategory = getCategory;
