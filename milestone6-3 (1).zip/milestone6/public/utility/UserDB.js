var User = require('../models/User');
var UserConnection = require('../models/UserConnection');

// get All users function
var getUsers = function(){
     return new Promise( function(resolve, reject){
         User.find().then(function(users){
             resolve(users);
         }).catch(function(err){
             console.log(err);
             return reject(err);
         });
     });   
   }

// get user with user id 
var getUser = function(userID){
     return new Promise(function(resolve, reject){
         User.findOne({userID:userID}).then(function(user){
             resolve(user);
             console.log(user)
         }).catch(function(err){
             console.log(err);
             return reject(err);
         });
   
     });  
   }

// get user with email and password
var getUserByEmail = async function(email,password){
    return new Promise(function(resolve, reject){
        User.find({email:email,password:password}).then(function(user){
            resolve(user);
        }).catch(function(err){
            console.log(err);
            return reject(err);
        });
  
    });  
  }

// get user with  only email  
var getUserByUsername = async function(email){
    return new Promise(function(resolve, reject){
        User.find({email:email}).then(function(user){
            resolve(user);
        }).catch(function(err){
            console.log(err);
            return reject(err);
        });
  
    });  
  }

module.exports.getUsers = getUsers;
module.exports.getUser = getUser;
module.exports.getUserByEmail = getUserByEmail;
module.exports.getUserByUsername = getUserByUsername;

