var UserConnection = require('../models/UserConnection');
var connectionDB = require('../utility/connectionDB');
var Connection = require('../models/connection');
var User = require('../models/User');

// Displays the user profile based on the userID

var getUserProfile = async function(userID){
    return new Promise(function(resolve, reject){
        UserConnection.find({userID:userID}).then(function(doc){
            resolve(doc);
        }).catch(function(err){
            return reject(err);
        });
    });
}

//Removes a connection from the user profile based on the connection id
var removeConnection =  function(conID,userID){
  return new Promise(function(resolve, reject){
    UserConnection.findOneAndRemove({conID: conID,userID:userID}, function(err){
        if(err){
            reject(err);
        }
          UserConnection.find({userID:userID}).then(function(connection){
          resolve(connection);
          }).catch(function(err){
            return reject(err);
          });    
       });
        });
}

// Updates the rsvp of a user connection
var updateRSVP = function(conID, userID , rsvp){
    return new Promise(function(resolve,reject) {
        UserConnection.update({conID:conID,userID:userID},{$set:{rsvp:rsvp}},function(err){
            if (err){
              return console.error(err);
            } 
            UserConnection.find({userID:userID}).then(function(connection){
            resolve(connection);
            }).catch(function(err) {
            return reject(err);
            console.log(err);
            });
        });  
      });
}

//adds a connection to the user profile
var addRSVP =  async function(conID, rsvp , userID,host){
    var connection = await connectionDB.getConnection(conID);
    return new Promise(function(resolve,reject){
      UserConnection.update({conID:conID,rsvp:rsvp,userID:userID,hostedBy:host},{$setOnInsert:{conName:connection.connectionName,
        conTopic:connection.connectionTopic}},{upsert:true},function(err){
      if(err) {
        return console.log(err);
      }
      UserConnection.find({userID:userID}).then(function(connection) {
        resolve(connection);
      }).catch(function(err) {
        return reject(err);
      });
    });
    });
}


// adds a new connection to the database
var addConnection = function(conID,name,topic,details,location,host,date,time,userID){
  console.log("Adding a new connection to the database")
  var newConnection = new Connection({
     connectionID : conID,
     connectionName : name,
     connectionTopic : topic,
     connectionDetails : details,
     location : location,
     hostedBy : host,
     date : date,
     time : time,
     image: '/assets/images/default.jpg',
     going_yes : 'Yes',
     going_no : 'No',
     going_maybe : 'Maybe',
     userID : userID});
    newConnection.save();
  var userProfile = new UserConnection({
     conID: conID,
     conName : name,
     conTopic : topic,
     rsvp : 'Yes',
     userID: userID,
     hostedBy : host
  });
  userProfile.save();
}

/*----------Remove a connection from the database------------*/
var removeConFromDB =  function(conID,connections,userID,host){
  return new Promise(function(resolve, reject){
    Connection.findOneAndRemove({connectionID: conID,userID:userID,hostedBy:host}, function(err){
        if(err){
            reject(err);
        }
          Connection.find({connectionID:conID,hostedBy:host}).then(function(connection){
          resolve(connection);
          }).catch(function(err){
            return reject(err);
          });    
       });
        });
}

/* -- Update a connection in the database ----*/
var updateConnection = function(conID,cTopic,cName,cDetails,date,location,time,host){
    Connection.update({connectionID:conID},{$set:{connectionTopic:cTopic,connectionName:cName,
      connectionDetails:cDetails,date:date,location:location,time:time}},function(err){
        console.log(Connection);
      });
    UserConnection.update({conID:conID},{$set:{conTopic:cTopic,conName:cName,hostedBy:host}},function(err){
    });
  }
  
module.exports.getUserProfile = getUserProfile;
module.exports.removeConnection = removeConnection;
module.exports.updateRSVP = updateRSVP;
module.exports.addRSVP = addRSVP;
module.exports.addConnection = addConnection;
module.exports.removeConFromDB = removeConFromDB;
module.exports.updateConnection = updateConnection;
