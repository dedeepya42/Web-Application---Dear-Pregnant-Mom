var express = require('express');
var app = express();
app.set('view engine','ejs');
app.use('/assets',express.static('assets'));
var connectionController = require('./routes/connectionController');
var profileController = require('./routes/profileController');
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/pregnantMomDB');

// routes defining
app.use(profileController);
app.use('/', connectionController);
app.use('/connections/connectionid=:connectionID',connectionController);
app.use('/connections',connectionController);
app.use('/myConnections',connectionController);
app.use('/contact', connectionController);
app.use('/about', connectionController);
app.use('/newConnection', connectionController);
app.use('/*',connectionController);
app.listen(8080,function(){
    console.log('The app has started')
    console.log('Now listening on port 8080')
});
